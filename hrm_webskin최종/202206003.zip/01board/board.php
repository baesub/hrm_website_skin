<?php
// 01/board/board.php
include $_SERVER['DOCUMENT_ROOT']."202206003/_include.header.php";
// 절대경로 c:xampp/htdocs/
?>
<!-- http://localhost/202206003/01board/board.php
몸통 -->
<?
include $_SERVER['DOCUMENT_ROOT']."202206003/_include.footer.php";
?>