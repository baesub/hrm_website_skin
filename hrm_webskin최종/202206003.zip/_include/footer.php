<div id="footer">
        <div class="container">

            <!-- ----------- // -->
            <div class="bot_nav">
<a href="/others/privacy">개인정보처리방침</a><a href="/board/thirdoffer">개인정보 제3자제공</a><a href="/@resource/file/개인정보활용동의서.zip">개인정보활용동의서</a><a href="/others/open_info">정보공개</a><a href="https://www.academyinfo.go.kr/popup/pubinfo1690/list.do?schlId=0000479" target = "_blank" >대학정보공시</a><a href="/others/budget">예결산공고</a><a href="/board/tender">입찰공고</a><a href="/others/corporate">법인현황</a><a href="/others/self_assessment">자체평가결과공고</a><a href="/others/tuition">등록금심의위원회</a><a href="/others/council">대학평의원회</a><a href="/others/directorate">이사회</a><a href="/board/meeting">회의록공지게시판</a><a href="/board/bizpay">업무추진비사용내역</a><a href="/board/donate">연간기부모금액 및 활용실적공개</a><a href="/@resource/file/2023최저임금공시.pdf" target = "_blank" >2023최저임금공시</a><a href="/others/banners">외부배너모음</a>            </div>
            <!-- ----------- m -->
            <div class="bot_nav_m">
                <div>
                    <ul>
<li><a href="/others/privacy">개인정보처리방침</a></li><li><a href="/board/thirdoffer">개인정보 제3자제공</a></li><li><a href="/@resource/file/개인정보활용동의서.zip">개인정보활용동의서</a></li><li><a href="/others/open_info">정보공개</a></li><li><a href="https://www.academyinfo.go.kr/popup/pubinfo1690/list.do?schlId=0000479" target = "_blank" >대학정보공시</a></li><li><a href="/others/budget">예결산공고</a></li><li><a href="/board/tender">입찰공고</a></li><li><a href="/others/corporate">법인현황</a></li><li><a href="/others/self_assessment">자체평가결과공고</a></li><li><a href="/others/tuition">등록금심의위원회</a></li><li><a href="/others/council">대학평의원회</a></li><li><a href="/others/directorate">이사회</a></li><li><a href="/board/meeting">회의록공지게시판</a></li><li><a href="/board/bizpay">업무추진비사용내역</a></li><li><a href="/board/donate">연간기부모금액 및 활용실적공개</a></li><li><a href="/@resource/file/2023최저임금공시.pdf" target = "_blank" >2023최저임금공시</a></li><li><a href="/others/banners">외부배너모음</a></li>                    </ul>
                </div>
            </div>

            <div class="addr">
                <span>부산경상대학교</span>
                <span>주소 (47583) 부산광역시 연제구 고분로 170(연산동 277-4번지)</span>
                <span>사업자번호 607-82-05457</span>
                <strong>입학상담문의 051-850-1004</strong>
            </div>
            <div class="copyright">ⓒ2023 Busan KyungSang College All rights Reserved.</div>

            <!-- ----------- // -->
            <div class="nav_select">
                <div class="selectbx type1">
                    <div class="selected">
                        <span class="chk_v">학교법인 화신학원</span>
                    </div>
                    <ul class="select_ul">
                        <li class="opt"><a href="https://www.bsks.ac.kr/" target="_blank">부산경상대학교</a></li>
                        <li class="opt"><a href="https://www.hscu.ac.kr/" target="_blank">화신사이버대학교</a></li>
                        <li class="opt"><a href="https://school.busanedu.net/" target="_blank">부산외국어고등학교</a></li>
                        <li class="opt"><a href="#">부산경상대학교 부속유치원</a></li>
                        <li class="opt"><a href="https://detc.bsks.ac.kr/detc/bbs/content.php?co_id=kinder_service" target="_blank">BSKS반려견유치원</a></li>
                    </ul>
                </div>

                <div class="selectbx type2">
                    <div class="selected">
                        <span class="chk_v">부산경상대학교 위탁운영기관</span>
                    </div>
                    <ul class="select_ul">
                        <li class="opt"><a href="http://gjcw.or.kr/" target="_blank">거제종합사회복지관</a></li>
                        <li class="opt"><a href="http://yjscfc.or.kr/" target="_blank">연제구육아종합지원센터</a></li>
                        <li class="opt"><a href="https://detc.bsks.ac.kr/detc/bbs/content.php?co_id=play_guide" target="_blank">부산시반려견교육놀이터</a></li>
                        <li class="opt"><a href="https://www.yeonje.go.kr/welfare/contents.do?mId=0407050000" target="_blank">연제구다함께돌봄센터</a></li>
                    </ul>
                </div>
            </div>
            <!-- ----------- m -->
            <div class="nav_select_m">
                <div class="selectbx_m">
                    <select onchange="window.open(this.value, '_blank');">
                        <option value="https://www.bsks.ac.kr/">부산경상대학교</option>
                        <option value="https://www.hscu.ac.kr/">화신사이버대학교</option>
                        <option value="https://school.busanedu.net/">부산외국어고등학교</option>
                        <option value="#">부산경상대학교 부속유치원</option>
                        <option value="https://detc.bsks.ac.kr/detc/bbs/content.php?co_id=kinder_service">BSKS반려견유치원</option>
                    </select>
                </div>

                <div class="selectbx_m">
                    <select onchange="window.open(this.value, '_blank');">
                        <option value="http://gjcw.or.kr/">거제종합사회복지관</option>
                        <option value="http://yjscfc.or.kr/">연제구육아종합지원센터</option>
                        <option value="https://detc.bsks.ac.kr/detc/bbs/content.php?co_id=play_guide">부산시반려견교육놀이터</option>
                        <option value="https://www.yeonje.go.kr/welfare/contents.do?mId=0407050000">연제구다함께돌봄센터</option>
                    </select>
                </div>
            </div>
            <div class="bot_bnr">
                <a href="https://www.toonboom.com" target="_blank">
                   <img src="/@resource/images/coe_logo.png" alt="Toon Boom Animation">
                </a>
            </div>
            <div class="bot_sns">
                <a href="https://blog.naver.com/prologue/PrologueList.naver?blogId=yesbsks" target="_blank"><img src="/@resource/images/bot_blog.png" alt="블로그"></a>
                <a href="https://www.instagram.com/official_bsks/" target="_blank"><img src="/@resource/images/bot_insta.png" alt="인스타그램"></a>
                <a href="https://www.facebook.com/bsksofficial" target="_blank"><img src="/@resource/images/bot_fb.png" alt="페이스북"></a>
                <a href="https://pf.kakao.com/_EUlfu" target="_blank"><img src="/@resource/images/bot_kko.png" alt="카카오"></a>
            </div>
        </div>
    </div>

    <div class="btnup">
        <a href="#"><img src="/@resource/images/btnup.png" alt="위로" /></a>
    </div>

