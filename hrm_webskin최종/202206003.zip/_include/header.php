
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>부산경상대학교  : 학교상징</title>
	<link rel="shortcut icon" href="/@resource/images/favicon.ico">
	<link rel="stylesheet" href="/@resource/css/contents.css?1697600433" type="text/css">	<!-- SEO 영역 -->
	<meta name="title" content="부산경상대학교">
	<meta name="keywords" content="부산경상대학교, 부산경상대학, 부산경상대, 경상대학교, 경상대, 전문대, 전문대학, 전문대학교, 부산전문대, 부산대학, 2년제, 3년제">
	<meta name="twitter:card" content="photo">
	<meta name="twitter:title" content="부산경상대학교">
	<meta name="twitter:description" content="부산광역시 연제구에 위치한 사립전문대학 부산경상대학교의 홈페이지입니다. 대학 및 학과 소개, 입시정보를 친절하게 제공해드립니다.">
	<meta name="twitter:image" content="/@resource/images/og_image.png">
	<meta name="twitter:url" content="https://www.bsks.ac.kr/">
	<meta name="description" content="부산광역시 연제구에 위치한 사립전문대학 부산경상대학교의 홈페이지입니다. 대학 및 학과 소개, 입시정보를 친절하게 제공해드립니다.">
	<meta property="og:type" content="website">
	<meta property="og:title" content="부산경상대학교">
	<meta property="og:description" content="부산광역시 연제구에 위치한 사립전문대학 부산경상대학교의 홈페이지입니다. 대학 및 학과 소개, 입시정보를 친절하게 제공해드립니다.">
	<meta property="og:image" content="/@resource/images/og_image.png">
	<meta property="og:url" content="https://www.bsks.ac.kr/">
	<!-- -->
    <script src="/@resource/js/jquery-1.12.4.min.js"></script>
    <script src="/@resource/js/waypoints.min.js"></script>
    <script src="/@resource/js/counterup.min.js"></script>
    <script src="/@resource/js/jquery.custom.js"></script>
    <script src="/@resource/js/zoom.js"></script>
</head>

<body>
    <!-- header m -->
    <div class="dimmed"></div>
    <nav class="nav_open_wrap">
        <div class="nav_hd clear">
            <span><a href="/"><img src="/@resource/images/logo.png" /></a></span>
            <div class="m-close-btn"><img src="/@resource/images/m-nav-close.png" /></div>
        </div>

        <div class="nav_bnr none">
            <div class="bnr">
                <span class="nav_tel"><img src="/@resource/images/m-nav-tel.png" /> <em>입학상담</em> <a href="tel:051-850-1004">051-850-1004</a></span>
                <span class="nav_kko"><a href="https://pf.kakao.com/_EUlfu"><img src="/@resource/images/m-nav-kko.png" /> <em>카톡문의</em></a></span>
            </div>
        </div>
        <div class="nav_bnr_img">
        	<a target="_blank" href="https://www.youtube.com/watch?v=oY-Rl_zqIJE">
            	<img src="/@resource/banner/@top_bnr02-1(230816).jpg" alt=""><!--banner-->
            </a>
        </div>
        <div class="nav_list">
            <ul class="nav_wrap">
				<li><a>대학소개</a>
					<ul class="nav_list_s">
						<li><a href="/intro/greet">총장소개</a></li>
						<li><a href="/intro/history">학교연혁</a></li>
						<li><a href="/intro/symbol">학교상징</a></li>
						<li><a href="/intro/organization">대학기구표</a></li>
						<li><a href="/intro/plan">대학발전계획</a></li>
						<li><a href="/intro/sponsor">대학발전후원회</a></li>
						<li><a href="/intro/campus">캠퍼스안내</a></li>
						<li><a href="/intro/our_ks">자랑스러운 잔메인상</a></li>
					</ul>
				</li>
				<li><a>학과안내</a>
					<ul class="nav_list_s">
						<li><a href="/department/human">인문경상학부</a></li>
						<li><a href="/department/contents">문화콘텐츠산업학부</a></li>
						<li><a href="/department/life">평생교육학부</a></li>
						<li><a href="/department/deep">학사학위전공심화과정</a></li>
					</ul>
				</li>
				<li><a>대학생활</a>
					<ul class="nav_list_s">
						<li><a href="/notice">공지사항</a></li>
						<li><a href="/news">캠퍼스뉴스</a></li>
						<li><a href="/college/rule">학사정보</a></li>
						<li><a href="/campus/calendar">학사일정</a></li>
						<li><a href="/scholarship">장학정보</a></li>
						<li><a href="/nationwork">근로제도안내</a></li>
						<li><a href="https://job.bsks.ac.kr/" target = "_blank" >취업안내</a></li>
						<li><a href="https://bsgs.certpia.com/" target = "_blank" >증명서발급안내</a></li>
						<li><a href="/campus/autonomy">학생복지안내</a></li>
						<li><a href="/campus/dorm">기숙사안내</a></li>
						<li><a href="/qna">재학생 Q&A</a></li>
					</ul>
				</li>
				<li><a>교내사이트</a>
					<ul class="nav_list_s">
						<li><a href="https://ais.bsks.ac.kr/" target = "_blank" >학사종합서비스</a></li>
						<li><a href="https://charm.bsks.ac.kr/" target = "_blank" >역량기반운영관리시스템</a></li>
						<li><a href="https://newlms.bsks.ac.kr/" target = "_blank" >E-러닝지원센터</a></li>
						<li><a href="https://iphak.bsks.ac.kr/" target = "_blank" >입학홈페이지</a></li>
						<li><a href="https://ctl.bsks.ac.kr/home/index.php" target = "_blank" >교수학습지원센터</a></li>
						<li><a href="https://hive.bsks.ac.kr/" target = "_blank" >HiVE 연제구취창업비전교육센터</a></li>
						<li><a href="https://lib.bsks.ac.kr" target = "_blank" >일민도서관</a></li>
						<li><a href="https://job.bsks.ac.kr/" target = "_blank" >취창업지원센터</a></li>
						<li><a href="https://www.bsks.ac.kr/scc/scc.asp" target = "_blank" >학생진로심리상담센터</a></li>
						<li><a href="https://lifeedu.bsks.ac.kr/" target = "_blank" >평생교육원</a></li>
						<li><a href="https://iea.bsks.ac.kr/" target = "_blank" >국제교류센터</a></li>
						<li><a href="https://press.bsks.ac.kr/gnu/" target = "_blank" >부산경상대학보</a></li>
						<li><a href="https://detc.bsks.ac.kr/detc/" target = "_blank" >반려동물교육문화센터</a></li>
						<li><a href="https://hrd.bsks.ac.kr/" target = "_blank" >일학습병행 공동훈련센터</a></li>
					</ul>
				</li>
            </ul>
            <div class="nav_etc">
                <a href="https://iphak.bsks.ac.kr/main" target="_blank">입학 홈페이지</a>
                <a href="https://iea.bsks.ac.kr/" target="_blank">외국인입학</a>
            </div>
        </div>
    </nav>
    <div class="fixed_bot">
        <ul>
			<li class="bot4"><a href="https://iphak.bsks.ac.kr"><img src="/@resource/images/m-fixed04.png" alt="입학홈페이지"></a></li>
            <li class="bot1"><a href="https://pf.kakao.com/_EUlfu"><img src="/@resource/images/m-fixed01.png" alt="카카오톡 입학정보"></a></li>
            <li class="bot2"><a href="/department"><img src="/@resource/images/m-fixed02.png" alt="학과소개"></a></li>
            <li class="bot3"><a href="https://bsgs.certpia.com/"><img src="/@resource/images/m-fixed03.png" alt="증명서발급"></a></li>
        </ul>
    </div>
    <!-- ----------- // -->

    <div class="fixed_side_o">
		<a href="https://iphak.bsks.ac.kr" target="_blank"><img src="/@resource/images/fixed04.png" alt="입학홈페이지"></a>
        <a href="https://pf.kakao.com/_EUlfu" target="_blank"><img src="/@resource/images/fixed01.png" alt="카카오톡 입학정보"></a>
        <a href="/department"><img src="/@resource/images/fixed02.png" alt="학과소개"></a>
        <a href="https://bsgs.certpia.com/" target="_blank"><img src="/@resource/images/fixed03.png" alt="증명서발급"></a>
    </div>

    <!-- header -->
    <div id="header">
        <div class="lnb">
            <div class="container">
                <div class="text_zoom">
                    <span>글자크기</span>
                    <a href="javascript:zoomOut();"><img src="/@resource/images/zoom_in.png" alt=""></a>
                    <a href="javascript:zoomIn();"><img src="/@resource/images/zoom_out.png" alt=""></a>
                </div>
                <div class="lnb_a">
                    <a href="https://iphak.bsks.ac.kr/" target="_blank" class="home">입학 홈페이지</a>
                    <a href="https://iea.bsks.ac.kr/" target="_blank">외국인입학</a>
                </div>
            </div>
        </div>

        <div class="hd">
            <div class="container">
                <h1 class="logo"><a href="/"><img src="/@resource/images/logo.png" alt="부산경상대학교" /></a></h1>
                <div class="nav_open" id="btn_nav">
                    <img src="/@resource/images/m-nav-open.png" />
                </div>

                <div class="gnb">
                    <ul>
<li><a>대학소개</a></li><li><a>학과안내</a></li><li><a>대학생활</a></li><li><a>교내사이트</a></li>                    </ul>
                </div>
                <div class="sch_open">
                    <input type="text" class="inp" placeholder="검색어를 입력해 주세요" /><a href="/search"><img src="/@resource/images/btn_search.png" class="btn_sch"/></a>
                    <span class="sch_close"></span>
                </div>
                <span class="btn_search open"></span>
                <span class="btn_sitemap open"></span>
            </div>


            <div class="gnb_full_wrap">
                <div class="gnb_full_inner">
                    <ul>
<li class="g01"><h2>대학소개</h2><ul><li class="d2"><p>총장소개</p><span><a href="/intro/greet">- 인사말</a><a href="/intro/principal">- 역대총장</a></span></li><li><a href="/intro/history">학교연혁</a></li><li><a href="/intro/symbol">학교상징</a></li><li class="d2"><p>대학기구표</p><span><a href="/intro/organization">- 조직도</a><a href="/intro/dept">- 부서소개</a></span></li><li class="d2"><p>대학발전계획</p><span><a href="/intro/plan">- 설립이념 및 학훈</a><a href="/intro/people">- 대학인재상</a><a href="/intro/vision">- VISION 2025+</a><a href="/intro/ethics">- 윤리강령</a></span></li><li><a href="/intro/sponsor">대학발전후원회</a></li><li class="d2"><p>캠퍼스안내</p><span><a href="/intro/campus">- 캠퍼스안내</a><a href="/intro/woonjung">- 운정연수원</a><a href="http://vrpanosky.com/wp-content/uploads/2021/05/kyungsang_/index.html" target = "_blank" >- 캠퍼스VR투어</a></span></li><li><a href="/intro/our_ks">자랑스러운 잔메인상</a></li></ul></li><li class="g02"><h2>학과안내</h2><ul><li><a href="/department/human">인문경상학부</a></li><li><a href="/department/contents">문화콘텐츠산업학부</a></li><li><a href="/department/life">평생교육학부</a></li><li><a href="/department/deep">학사학위전공심화과정</a></li></ul></li><li class="g03"><h2>대학생활</h2><ul><li class="d2"><p>공지사항</p><span><a href="/notice">- 학사공지</a><a href="/notice/general">- 일반공지</a><a href="/notice/scholar">- 장학공지</a><a href="/notice/recruit">- 채용공지</a><a href="/notice/contest">- 공모전알림</a></span></li><li><a href="/news">캠퍼스뉴스</a></li><li class="d2"><p>학사정보</p><span><a href="/college/rule">- 학사규정</a><a href="/college/register">- 등록안내</a><a href="/college/apply">- 수강신청안내</a><a href="/college/record">- 성적관리안내</a><a href="/college/leave">- 휴학안내</a><a href="/college/back">- 복학안내</a><a href="/college/readmission">- 재입학안내</a><a href="/college/change">- 전과안내</a><a href="/college/graduation">- 졸업기준안내</a></span></li><li><a href="/campus/calendar">학사일정</a></li><li class="d2"><p>장학정보</p><span><a href="/scholarship/fresher">- 신입생장학제도</a><a href="/scholarship/fresher_special">- 신입생특별장학제도</a><a href="/scholarship/student">- 재학생장학제도</a><a href="/scholarship/student_special">- 재학생특별장학제도</a><a href="/scholarship/loan">- 학자금대출안내</a></span></li><li class="d2"><p>근로제도안내</p><span><a href="/nationwork/info">- 국가근로안내</a><a href="/nationwork/vacation">- 교외근로 방학기간 운영</a><a href="/nationwork/attention">- 주의사항</a><a href="/nationwork/paper">- 서류양식안내</a></span></li><li><a href="https://job.bsks.ac.kr/" target = "_blank" >취업안내</a></li><li><a href="https://bsgs.certpia.com/" target = "_blank" >증명서발급안내</a></li><li class="d2"><p>학생복지안내</p><span><a href="/campus/autonomy">- 학생자치활동</a><a href="/campus/club">- 동아리</a><a href="/campus/office365">- Office365</a></span></li><li class="d2"><p>기숙사안내</p><span><a href="/campus/dorm">- 기숙사안내</a><a href="/campus/dorm_qna">- 기숙사Q&A</a></span></li><li><a href="/qna">재학생 Q&A</a></li></ul></li><li class="g04"><h2>교내사이트</h2><ul><li><a href="https://ais.bsks.ac.kr/" target = "_blank" >학사종합서비스</a></li><li><a href="https://charm.bsks.ac.kr/" target = "_blank" >역량기반운영관리시스템</a></li><li><a href="https://newlms.bsks.ac.kr/" target = "_blank" >E-러닝지원센터</a></li><li><a href="https://iphak.bsks.ac.kr/" target = "_blank" >입학홈페이지</a></li><li><a href="https://ctl.bsks.ac.kr/home/index.php" target = "_blank" >교수학습지원센터</a></li><li><a href="https://hive.bsks.ac.kr/" target = "_blank" >HiVE 연제구취창업비전교육센터</a></li><li><a href="https://lib.bsks.ac.kr" target = "_blank" >일민도서관</a></li><li><a href="https://job.bsks.ac.kr/" target = "_blank" >취창업지원센터</a></li><li><a href="https://www.bsks.ac.kr/scc/scc.asp" target = "_blank" >학생진로심리상담센터</a></li><li><a href="https://lifeedu.bsks.ac.kr/" target = "_blank" >평생교육원</a></li><li><a href="https://iea.bsks.ac.kr/" target = "_blank" >국제교류센터</a></li><li><a href="https://press.bsks.ac.kr/gnu/" target = "_blank" >부산경상대학보</a></li><li><a href="https://detc.bsks.ac.kr/detc/" target = "_blank" >반려동물교육문화센터</a></li><li><a href="https://hrd.bsks.ac.kr/" target = "_blank" >일학습병행 공동훈련센터</a></li></ul></li>                    </ul>
                </div>
            </div>

            <div class="sitemap">
                <div class="sitemap_open">
                    <span class="btn_sitemap_close"><img src="/@resource/images/btn_sitemap_close.png" alt=""></span>
                    <p><img src="/@resource/images/logo_b.png" alt=""></p>
                    <ul>
<li class="m1"><strong>대학소개</strong><ul><li class="d2"><span>총장소개</span><a href="/intro/greet">- 인사말</a><a href="/intro/principal">- 역대총장</a></li><li><a href="/intro/history">학교연혁</a></li><li><a href="/intro/symbol">학교상징</a></li><li class="d2"><span>대학기구표</span><a href="/intro/organization">- 조직도</a><a href="/intro/dept">- 부서소개</a></li><li class="d2"><span>대학발전계획</span><a href="/intro/plan">- 설립이념 및 학훈</a><a href="/intro/people">- 대학인재상</a><a href="/intro/vision">- VISION 2025+</a><a href="/intro/ethics">- 윤리강령</a></li><li><a href="/intro/sponsor">대학발전후원회</a></li><li class="d2"><span>캠퍼스안내</span><a href="/intro/campus">- 캠퍼스안내</a><a href="/intro/woonjung">- 운정연수원</a><a href="http://vrpanosky.com/wp-content/uploads/2021/05/kyungsang_/index.html" target = "_blank" >- 캠퍼스VR투어</a></li><li><a href="/intro/our_ks">자랑스러운 잔메인상</a></li></ul></li><li class="m2"><strong>학과안내</strong><ul><li><a href="/department/human">인문경상학부</a></li><li><a href="/department/contents">문화콘텐츠산업학부</a></li><li><a href="/department/life">평생교육학부</a></li><li><a href="/department/deep">학사학위전공심화과정</a></li></ul></li><li class="m3"><strong>대학생활</strong><ul><li class="d2"><span>공지사항</span><a href="/notice">- 학사공지</a><a href="/notice/general">- 일반공지</a><a href="/notice/scholar">- 장학공지</a><a href="/notice/recruit">- 채용공지</a><a href="/notice/contest">- 공모전알림</a></li><li><a href="/news">캠퍼스뉴스</a></li><li class="d2"><span>학사정보</span><a href="/college/rule">- 학사규정</a><a href="/college/register">- 등록안내</a><a href="/college/apply">- 수강신청안내</a><a href="/college/record">- 성적관리안내</a><a href="/college/leave">- 휴학안내</a><a href="/college/back">- 복학안내</a><a href="/college/readmission">- 재입학안내</a><a href="/college/change">- 전과안내</a><a href="/college/graduation">- 졸업기준안내</a></li><li><a href="/campus/calendar">학사일정</a></li><li class="d2"><span>장학정보</span><a href="/scholarship/fresher">- 신입생장학제도</a><a href="/scholarship/fresher_special">- 신입생특별장학제도</a><a href="/scholarship/student">- 재학생장학제도</a><a href="/scholarship/student_special">- 재학생특별장학제도</a><a href="/scholarship/loan">- 학자금대출안내</a></li><li class="d2"><span>근로제도안내</span><a href="/nationwork/info">- 국가근로안내</a><a href="/nationwork/vacation">- 교외근로 방학기간 운영</a><a href="/nationwork/attention">- 주의사항</a><a href="/nationwork/paper">- 서류양식안내</a></li><li><a href="https://job.bsks.ac.kr/" target = "_blank" >취업안내</a></li><li><a href="https://bsgs.certpia.com/" target = "_blank" >증명서발급안내</a></li><li class="d2"><span>학생복지안내</span><a href="/campus/autonomy">- 학생자치활동</a><a href="/campus/club">- 동아리</a><a href="/campus/office365">- Office365</a></li><li class="d2"><span>기숙사안내</span><a href="/campus/dorm">- 기숙사안내</a><a href="/campus/dorm_qna">- 기숙사Q&A</a></li><li><a href="/qna">재학생 Q&A</a></li></ul></li><li class="m4"><strong>교내사이트</strong><ul><li><a href="https://ais.bsks.ac.kr/" target = "_blank" >학사종합서비스</a></li><li><a href="https://charm.bsks.ac.kr/" target = "_blank" >역량기반운영관리시스템</a></li><li><a href="https://newlms.bsks.ac.kr/" target = "_blank" >E-러닝지원센터</a></li><li><a href="https://iphak.bsks.ac.kr/" target = "_blank" >입학홈페이지</a></li><li><a href="https://ctl.bsks.ac.kr/home/index.php" target = "_blank" >교수학습지원센터</a></li><li><a href="https://hive.bsks.ac.kr/" target = "_blank" >HiVE 연제구취창업비전교육센터</a></li><li><a href="https://lib.bsks.ac.kr" target = "_blank" >일민도서관</a></li><li><a href="https://job.bsks.ac.kr/" target = "_blank" >취창업지원센터</a></li><li><a href="https://www.bsks.ac.kr/scc/scc.asp" target = "_blank" >학생진로심리상담센터</a></li><li><a href="https://lifeedu.bsks.ac.kr/" target = "_blank" >평생교육원</a></li><li><a href="https://iea.bsks.ac.kr/" target = "_blank" >국제교류센터</a></li><li><a href="https://press.bsks.ac.kr/gnu/" target = "_blank" >부산경상대학보</a></li><li><a href="https://detc.bsks.ac.kr/detc/" target = "_blank" >반려동물교육문화센터</a></li><li><a href="https://hrd.bsks.ac.kr/" target = "_blank" >일학습병행 공동훈련센터</a></li></ul></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>