package com.board.domain;

public class BuseoCode extends CommonDTO {
	
	int code;
	String bname;
	String yn;
	
}

