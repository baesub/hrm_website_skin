package com.board.domain;

public class InsaBasic extends CommonDTO {
	
	// 인사기본사항 list. . .
	
	String 인사기본사항;
	String yn;
	
	
}
